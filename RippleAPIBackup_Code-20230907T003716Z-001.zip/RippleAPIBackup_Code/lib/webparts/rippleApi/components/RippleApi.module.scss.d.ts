declare const styles: {
    addTrustbtn: string;
    rippleApi: string;
    container: string;
    grid: string;
    row: string;
    twocolumnlayout: string;
    'ms-Grid': string;
    onecolumnlayout: string;
    AppName: string;
    sectionheading: string;
    labelheading: string;
    addtrust: string;
    refresh: string;
    trustlines: string;
    theading: string;
    trustheading: string;
    column: string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
};
export default styles;
//# sourceMappingURL=RippleApi.module.scss.d.ts.map