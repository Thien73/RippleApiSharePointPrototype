import * as React from 'react';
import { IRippleApiProps } from './IRippleApiProps';
export default class RippleApi extends React.Component<IRippleApiProps, any> {
    constructor(props: any);
    run(): Promise<void>;
    sendXRP(): Promise<void>;
    transact(api: any): Promise<void>;
    private _textToAddressChanged;
    private _textAmountChanged;
    private _transferAmtClicked;
    render(): React.ReactElement<IRippleApiProps>;
}
//# sourceMappingURL=RippleApi copy.d.ts.map