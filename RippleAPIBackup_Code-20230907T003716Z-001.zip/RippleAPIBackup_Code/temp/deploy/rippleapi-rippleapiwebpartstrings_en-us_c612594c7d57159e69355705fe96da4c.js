define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "ServerName":"wss://s.altnet.rippletest.net:51233",
    "FromAddress":"rfbckFrRYtn7Q1ExRzJU9jdzEizfnQnE7c",
    "FromSecret":"ssZqmYWRg75UoYAa6E3fSfKUCb6dA"
  }
});
//"FromAddress":"rfbckFrRYtn7Q1ExRzJU9jdzEizfnQnE7c",
//"FromSecret":"ssZqmYWRg75UoYAa6E3fSfKUCb6dA"
//Generate Address - https://xrpl.org/xrp-testnet-faucet.html